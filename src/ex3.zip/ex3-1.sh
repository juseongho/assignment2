#!/bin/bash
num=$1
for ((i = i; i<$num; i++))
do
 echo "hello world"
done
exit 0
